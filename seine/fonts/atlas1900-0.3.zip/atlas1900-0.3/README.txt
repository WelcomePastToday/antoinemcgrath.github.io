ATLAS 1900 — version 0.3 (19 November 2026)
============================================

A typeface drawn after the gilt capitals on the cover of the Atlas des anciens
plans de Paris (Imprimerie nationale, 1900 printing), made for "La Seine, ses
îles et ses fantômes" (https://antoinemcgrath.com/seine/).

Files
-----
  Atlas1900-Regular.ttf    Regular
  Atlas1900-Bold.ttf       Bold
  web/*.woff2              the same two fonts for websites
  OFL.txt                  the licence

Install both .ttf files (macOS: double-click and choose Install Font; Windows:
right-click and choose Install). They form one family, "Atlas 1900", so an
application's Bold button switches between them.

What is in it
-------------
- Capitals, figures and the punctuation and accents French needs.
- The lowercase keys give small capitals: the cover has capitals only.
- Two forms of the comma, semicolon, apostrophe and quotation marks: a wedge,
  as on the cover's period lettering, and a round ball-and-tail form. With
  contextual alternates on (the default in browsers and most applications), a
  mark follows the word before it: the wedge after capitals ("EN 1900,"), the
  round form after small capitals ("en 1900,"). The "case" feature forces the
  wedge everywhere.

On the web:
  @font-face { font-family: "Atlas 1900"; font-weight: 400;
               src: url("web/Atlas1900-Regular.woff2") format("woff2"); }
  @font-face { font-family: "Atlas 1900"; font-weight: 700;
               src: url("web/Atlas1900-Bold.woff2") format("woff2"); }

Where it comes from
-------------------
Capitals traced from the cover scan of the David Rumsey Map Collection (item
12431.001, https://archive.org/details/dr_covers-to-histoire-generale-de-paris-atlas-des-anciens-plans-de-paris-r-12431001).
Characters the cover does not show were created to match: built from pieces of
its own letters or drawn to its measured stroke weights, with Cochard & David's
« Lettres monumentales » (c. 1885) as the guide. A reconstruction, not a period
font; work in progress.

Licence
-------
SIL Open Font License, Version 1.1 (OFL.txt): free to use, study, modify and
redistribute, including in commercial work; it may not be sold by itself.
