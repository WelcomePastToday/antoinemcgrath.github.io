ATLAS 1900 — version 0.4 (20 November 2026)
============================================

A typeface drawn after the gilt capitals on the cover of the Atlas des anciens
plans de Paris (Imprimerie nationale, 1900 printing), made for "La Seine, ses
îles et ses fantômes" (https://antoinemcgrath.com/seine/).

Files
-----
  Atlas1900-Regular.ttf    Regular
  Atlas1900-Bold.ttf       Bold
  web/*.woff2              the same two fonts for websites
  OFL.txt                  the licence

Install both .ttf files (macOS: double-click and choose Install Font; Windows:
right-click and choose Install). They form one family, "Atlas 1900", so an
application's Bold button switches between them.

What is in it
-------------
- Capitals, figures and the punctuation and accents French needs.
- The lowercase keys give small capitals: the cover has capitals only.
- The comma, semicolon, apostrophe and quotation marks are wedges, after the
  wedge-shaped ends of the cover's letters: opening quotes broad at the foot,
  closing quotes and the apostrophe broad at the head. One form everywhere;
  low quotes („ ‚) and the straight quotes (" ') are included.

On the web:
  @font-face { font-family: "Atlas 1900"; font-weight: 400;
               src: url("web/Atlas1900-Regular.woff2") format("woff2"); }
  @font-face { font-family: "Atlas 1900"; font-weight: 700;
               src: url("web/Atlas1900-Bold.woff2") format("woff2"); }

Where it comes from
-------------------
Capitals traced from the cover scan of the David Rumsey Map Collection (item
12431.001, https://archive.org/details/dr_covers-to-histoire-generale-de-paris-atlas-des-anciens-plans-de-paris-r-12431001).
Characters the cover does not show were created to match: built from pieces of
its own letters or drawn to its measured stroke weights, with Cochard & David's
« Lettres monumentales » (c. 1885) as the guide. A reconstruction, not a period
font; work in progress.

Changes
-------
  0.4  One form of the comma family, the wedge (0.3 had a ball-and-tail form
       in lowercase); low quotes „ ‚ and the straight ".
  0.3  First download: Regular and Bold, with small capitals.

Licence
-------
SIL Open Font License, Version 1.1 (OFL.txt): free to use, study, modify and
redistribute, including in commercial work; it may not be sold by itself.
